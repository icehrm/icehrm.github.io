<!-- Delete Modal -->
<div class="modal fade" id="deleteModel" tabindex="-1" role="dialog" aria-labelledby="deleteModelLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><li class="fa fa-times"/></button>
				<h3 id="deleteModelLabel" style="font-size: 17px;"></h3>
			</div>
			<div class="modal-body">
				<p id="deleteModelBody"></p>
			</div>
			<div class="modal-footer">
				<button class="btn" onclick="modJs.cancelDelete();">Cancel</button>
				<button class="btn btn-primary" onclick="modJs.confirmDelete();">Delete</button>
			</div>
		</div>
	</div>
</div>
<!-- Delete Modal -->

<!-- Message Modal -->
<div class="modal fade" id="messageModel" tabindex="-1" role="dialog" aria-labelledby="messageModelLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><li class="fa fa-times"/></button>
				<h3 id="messageModelLabel" style="font-size: 17px;"></h3>
			</div>
			<div class="modal-body">
				<p id="messageModelBody"></p>
			</div>
			<div class="modal-footer">
				<button class="btn" onclick="modJs.closeMessage();">Ok</button>
			</div>
		</div>
	</div>
</div>
<!-- Message Modal -->

<!-- Plain Message Modal -->
<div class="modal fade" id="plainMessageModel" tabindex="-1" role="dialog" aria-labelledby="plainMessageModelLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header" style="border-bottom:none;/*background-color: #3c8dbc;*/">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true" style="margin-top:-10px;"><li class="fa fa-times"/></button>
			</div>
			<div class="modal-body">
				<p id="plainMessageModelBody"></p>
			</div>
		</div>
	</div>
</div>
<!-- Plain Message Modal -->

<!-- Data Message Modal -->
<div class="modal fade" id="dataMessageModel" tabindex="-1" role="dialog" aria-labelledby="dataMessageModelLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header" style="border-bottom:none;/*background-color: #3c8dbc;*/">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true" style="margin-top:-10px;"><li class="fa fa-times"/></button>
			</div>
			<div class="modal-body">
				<p id="dataMessageModelBody"></p>
			</div>
		</div>
	</div>
</div>
<!-- Data Message Modal -->

<!-- Yes No Modal -->
<div class="modal fade" id="yesnoModel" tabindex="-1" role="dialog" aria-labelledby="yesnoModelLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><li class="fa fa-times"/></button>
				<h3 id="yesnoModelLabel" style="font-size: 17px;"></h3>
			</div>
			<div class="modal-body">
				<p id="yesnoModelBody"></p>
			</div>
			<div class="modal-footer">
				<button id="yesnoModelNoBtn" class="btn" onclick="modJs.cancelYesno();">No</button>
				<button id="yesnoModelYesBtn" class="btn btn-primary">Yes</button>
			</div>
		</div>
	</div>
</div>
<!-- Yes No Modal -->

<!-- Google Connect -->
<div class="modal fade" id="googleConnectModel" tabindex="-1" role="dialog" aria-labelledby="googleConnectModelLabel" aria-hidden="true">
    <div class="modal-dialog" style="width:500px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><li class="fa fa-times"/></button>
                <h3 id="googleConnectModelLabel" style="font-size: 17px;">Connect IceHrm to Google Calendar</h3>
            </div>
            <div class="modal-body">
                <p>
                    We have detected that your email address can be used with Google APIs, which will allow us to create google calendar events, based on your actions such as applying for a leave or scheduling an interview.
                    <br/>
                    Please connect your IceHrm account with Google to enable this feature.
                </p>
                <p id="googleConnectModelBody">
                    <img src="<?=BASE_URL?>images/icehrm-google-connect.png" width="100%"/>
                </p>
            </div>
            <div class="modal-footer">
                <a href="#" onclick="modJs.redirectToUrl('<?=CLIENT_BASE_URL?>google-connect.php');">
                    <img src="<?=BASE_URL?>images/btn_google_signin_dark_normal_web.png">
                </a>
            </div>
        </div>
    </div>
</div>
<!-- Google Connect -->

<!-- Upload Modal -->
<div class="modal fade" id="uploadModel" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><li class="fa fa-times"/></button>
				<h3 id="uploadModelLabel" style="font-size: 17px;"></h3>
			</div>
			<div class="modal-body">
				<p id="uploadModelBody"></p>
			</div>
			<div class="modal-footer">
				<button class="btn" onclick="$('#uploadModel').modal('hide');">Cancel</button>
			</div>
		</div>
	</div>
</div>
<!-- Upload Modal -->

<!-- The instance Verify modal was removed: instance verification is no longer part
     of the product and its backing service action (verifyInstance) is gone. -->


<?php if($user->user_level == 'Admin'){?>
	<!-- Modal -->
	<div class="modal fade" id="profileSwitchModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><li class="fa fa-times"/></button>
					<h4 id="myModalLabel"><?=t('Switch Employee')?></h4>
				</div>
				<div class="modal-body">
					<p><?=t('Select The Employee to Switch Into')?></p>
					<div style="border: solid 1px #EEE;">
						<select id="switch_emp" style="width:100%;">
							<!--
							<option value="-1">No Employee</option>
							-->
							<?php
							$employees = $baseService->get('Employee');
							foreach($employees as $empTemp){
								?>
								<option value="<?=htmlspecialchars($empTemp->id, ENT_QUOTES)?>"><?=htmlspecialchars($empTemp->first_name." ".$empTemp->last_name, ENT_QUOTES)?></option>
							<?php }?>
						</select>
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn" data-dismiss="modal" aria-hidden="true"><?=t('Close')?></button>
					<button class="btn btn-primary" onclick="modJs.setAdminProfile($('#switch_emp').val());return false;"><?=t('Switch')?></button>
				</div>
			</div>
		</div>
	</div>
	<!-- Modal -->
<?php }?>


<?php if(isset($itemNameLower)){?>
	<div class="modal" id="<?=$itemNameLower?>StatusModel" tabindex="-1" role="dialog" aria-labelledby="messageModelLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><li class="fa fa-times"/></button>
					<h3 style="font-size: 17px;">Change <?=$itemName?> Status</h3>
				</div>
				<div class="modal-body">
					<form id="expenseStatusForm">
						<div class="control-group">
							<label class="control-label" for="expense_status"><?=$itemName?> Status</label>
							<div class="controls">
								<select type="text" id="<?=$itemNameLower?>_status" class="form-control" name="<?=$itemNameLower?>_status" value="">

								</select>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="expense_status">Status Change Note</label>
							<div class="controls">
								<textarea id="<?=$itemNameLower?>_reason" class="form-control" name="<?=$itemNameLower?>_reason" maxlength="500"></textarea>
							</div>
						</div>
					</form>
				</div>
				<div class="modal-footer">
					<button class="btn btn-primary" onclick="modJs.changeStatus();">Change <?=$itemName?> Status</button>
					<button class="btn" onclick="modJs.closeDialog();">Not Now</button>
				</div>
			</div>
		</div>
	</div>
<?php } ?>
